(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.GrainLightpngcopy = function() {
	this.initialize(img.GrainLightpngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,500);


(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,899);


(lib.Shape13 = function() {
	this.initialize(img.Shape13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,314,192);


(lib.youre_in_textfade = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// youre_in
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5001").s().p("AgRAgIAJg/IAaAAIAAAEIgeA7g");
	this.shape.setTransform(-1.625,1.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5001").s().p("AAKA5QgCgDgBgHIADgQIAJgYIANghQACgIgBgDQgBgFgFAAQgFAAgIAJQgJAIgIAOIgRAdQgIARgFAQIgDAGIgVAAIAYhGIAEgOQACgGgBgEQAAgEgDgBQgEABgFAGQgGAHgHALIgDgBQAKgTALgKQAKgLAJgBQAGAAACAEQADADAAAGQAAAGgDAKIgGAVIgFAMQAGgKAIgLQAGgLAJgJQAIgJAJgGQAIgFAHgBQAJABADAEQADAFAAAIQgBAJgEALIgPAnQgFAMgBAHQgBAHADABQAEAAAGgIQAGgGAGgMIADABQgGANgHAJQgHAJgHAEQgHAFgGAAQgFAAgDgDg");
	this.shape_1.setTransform(33.125,7.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF5001").s().p("AgbBRQgCgDgBgHQAAgGADgKIAIgYIAJgXIAFgNQACgFgBgEQAAgEgDAAQgEAAgGAGQgGAHgGALIgEgCQALgSAKgKQALgLAIAAQAGAAAEADQADAEAAAGIgDAPIgHASIgKAeQgFANgBAHQgBAHAEAAQADAAAFgHQAGgHAGgLIADABQgGAMgHAJQgHAJgGAFQgHAEgGAAQgFAAgDgCgAAIg5QgEgEgBgHQABgGAEgFQAEgDAHAAQAGAAAFADQAEAFAAAGQAAAHgEAEQgFAFgGAAQgHAAgEgFg");
	this.shape_2.setTransform(25.025,5.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF5001").s().p("AgYA2QgLgHgGgMQgHgNABgRQgBgRAIgPQAHgPANgIQANgJAPAAQAOABAIAFQAKAFAEAJQAFAJgBAKIAAAFIhLAAIAAAEIAAAEQAAAQAEAKQAGALAIAFQAIAFAKAAQAOAAAJgJQAJgHAEgPIADAAQgBAPgFAMQgGALgKAHQgLAFgPABQgNAAgLgGgAgPgrQgHAHgEANIAuAAIAFgBIABgEQAAgFgCgFQgCgGgFgDQgFgDgHgBQgLABgJAHg");
	this.shape_3.setTransform(11.3,7.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF5001").s().p("AgkA7IAAgDQAGgBADgCQADgCACgDQABgEAAgGIAAhOIgSAAIAAgEIAngOIAAAfQAHgQAJgIQAJgHAMAAIADAAIAAAWIgFAAQgLAAgJAEQgIADgGAKIAAA5QAAAGACAEQACAEAEABIAMADIAAADg");
	this.shape_4.setTransform(2.775,7.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF5001").s().p("AAYAkQgJALgKAGQgJAHgMAAQgOgBgHgIQgHgKAAgQIAAhDIgTAAIAAgDIAqgPIAABQQAAALAEAGQAFAGAJAAQAGAAAHgFQAGgDAHgHIAAhGIgTAAIAAgDIAqgPIAABnIASAAIAAADIgoAPg");
	this.shape_5.setTransform(-9.125,7.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF5001").s().p("AgcA1QgMgGgHgNQgHgOAAgTQAAgSAIgOQAHgNAMgIQANgGAPgBQAPAAAMAHQANAGAHANQAGANABAUQAAASgIANQgHAOgNAIQgMAGgPABQgQAAgMgHgAgXgoQgGAMgBAWQAAAQAEANQAEANAHAIQAIAIAJAAQAOAAAHgMQAIgLgBgWQAAgQgEgNQgDgNgIgIQgHgHgJgBQgOAAgIALg");
	this.shape_6.setTransform(-20.2,7.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF5001").s().p("AhGBLIABgEIAMgDQAFgBADgEQADgDACgHIAJggIgMhCIgEgNQgCgFgDgDQgDgDgEgBIABgEIA1AAIgBAEQgIABgEAFQgDAGABAKIALA6IAsg6QAHgKgBgGQgBgFgIgBIABgEIAqAAIgBAEQgJACgHAGQgHAGgIALIgxA/IgKAjQgCAHABADQABAEAEABQAEACAHABIgBAEg");
	this.shape_7.setTransform(-29.375,5.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.8,-22.2,81.69999999999999,44.5);


(lib.grain_mask2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// grain_mask2
	this.instance = new lib.GrainLightpngcopy();
	this.instance.setTransform(-149.5,-125);

	this.instance_1 = new lib.GrainLightpngcopy();
	this.instance_1.setTransform(-149.5,50);

	this.instance_2 = new lib.GrainLightpngcopy();
	this.instance_2.setTransform(-150.5,-300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(120));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150.5,-300,301,600);


(lib.for_a_show_textfade = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// for_a_show
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5001").s().p("AgNANQgEgFAAgIQAAgHAEgFQAGgGAHABQAJgBAEAGQAGAFAAAHQAAAIgGAFQgEAGgJAAQgHAAgGgGg");
	this.shape.setTransform(51.95,6.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5001").s().p("AgMBDIAGhKIg2BLIgEgBIAJhrIgBgHQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQgDAAgFAGQgFAGgHAMIgEgCQALgTAKgKQAKgKAJAAQAJAAACAHQACAIgCANIgHBGIAPgZIARgbIAPgbIAKgTIAEAAIgLBqQATgXALgQQALgRAFgLQAEgLAAgFQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAQgCAAgEAEQgFAEgGAJIgEgCQALgQAJgIQAJgHAIAAQAHAAACADQADAEAAAFQAAAKgKAQQgKAQgVAXIg0A6g");
	this.shape_1.setTransform(43.625,2.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF5001").s().p("AgeA6QgNgHgIgOQgHgPAAgWQgBgSAJgPQAHgPAOgIQAOgIAQAAQARAAAOAHQAMAHAIAPQAHAOAAAVQABATgJAPQgHAPgOAIQgOAIgQAAQgRAAgNgHgAgYgrQgIAMAAAZQgBAQAFAPQAEAPAJAHQAHAJALAAQAPAAAHgMQAJgNgBgYQAAgQgEgPQgEgPgIgHQgJgJgKAAQgOAAgIAMg");
	this.shape_2.setTransform(30.95,1.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF5001").s().p("AALBZIAAgEQAGgBADgCQAEgCABgDQACgEAAgHIAAg9QAAgMgFgGQgFgGgKgBQgIABgHAFQgIAFgGAHIAABEQAAAHACAEQABADAEACQADACAGABIAAAEIg5AAIAAgEQAFgBAEgCQAEgCABgDQACgEAAgHIAAiGIgUAAIAAgFIAtgPIAABLQAKgLAKgHQAKgGAMgBQAQABAIAJQAIALAAARIAABCQAAAHACAEQABADAEACQAEACAFABIAAAEg");
	this.shape_3.setTransform(19.325,-0.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF5001").s().p("AgXA/QgJgCgIgFIAAgnIADAAQAEAOAHAJQAGAIAIAFQAIADAHAAQAKAAAGgFQAFgFAAgJQAAgKgHgFQgGgGgKgEIgTgKQgJgDgHgIQgGgHgBgMQAAgMAGgIQAFgIAKgEQAJgEALAAQALAAAJACQAJADAJAEIAAAlIgEAAQgGgUgLgIQgKgJgLAAQgJgBgFAFQgFAEAAAIQABAJAGAFQAHAFAJAEIATAJQAJAFAHAIQAGAHABAOQgBASgMAKQgMAKgTAAQgLAAgKgCg");
	this.shape_4.setTransform(8.925,1.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF5001").s().p("AgyA5QgIgHAAgLQgBgGAEgFQADgFAKgFIAygaIAAgTQAAgKgFgGQgDgGgKAAQgIABgGAEQgGAEgDAGQgDAIABAIQgFACgFABIgKABQgCgGADgGQADgGAGgFIAOgMQALgIAIgEQAIgDAHAAQAPAAAHAJQAIAIAAAOIAABCQAAAIADAEQADADAFAAQADAAADgDQADgBADgFIAEADQgFAJgHAGQgGAHgKgBQgGABgFgCQgFgDgDgGQgDgGAAgKIAAgCQgFAOgKAIQgKAIgOAAQgOAAgHgIgAgVAQQgIAEgDAEQgEAEABAEQAAAGAEAFQAEAFAHAAQAMAAAIgKQAHgIABgQIAAgOg");
	this.shape_5.setTransform(-7.5031,1.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF5001").s().p("AgzBAIAZhNIAFgPQACgHgBgEQAAgFgDAAQgEAAgGAHQgGAHgIANIgDgCQAKgUAMgMQAMgMAKAAQAFAAABAEQADADAAAHQAAAGgDAKIgGAYIgFAMQAIgTAIgPQAKgPAIgIQAJgJAIAAQAGAAAEAEQACADAAAEIgBAGIgDAEIgHAAQgTABgRAaQgQAZgQAzIgBADg");
	this.shape_6.setTransform(-22.15,1.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF5001").s().p("AgrA2QgKgJAAgWQAAgOAFgOQAFgPAJgOQAJgNANgIQAMgJAQAAQARAAAKALQAKAKABAVQgBAOgEAOQgFAPgJAOQgKANgMAIQgNAJgPAAQgRAAgLgLgAACgyQgGAGgGALQgGAKgEANQgEALgDAMQgCAMAAAKQAAAMAEAFQADAGAHgBQAHABAHgHQAGgGAGgLQAFgLAFgMQAEgLADgMQACgMAAgKQAAgLgEgGQgDgGgHABQgIgBgGAHg");
	this.shape_7.setTransform(-31.525,1.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF5001").s().p("AhRBqQgEgCAAgEQAAgDACgDQACgEACgBIADAAQAFAEAGACQAFACAEABQAIAAAEgGQAFgFAEgMIAihzIgXAAIABgDIAXgIQAFgQAMgNQAKgNANgIQAOgHAOAAQAJAAAEADQAFACAAAFIgCAGIgFAFIgDAAQgGgFgGgDQgFgCgFAAQgJAAgGAFQgFAHgEAOIgEAQIAeAAIgEAPIggAAIgaBdQgEARgLANQgLAMgMAHQgOAHgMAAQgIAAgDgDg");
	this.shape_8.setTransform(-39.2,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45,-17.7,99.6,35.2);


(lib.button_withtext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// start_planning
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9FF98").s().p("AgcA5QgOgHgIgPQgIgPAAgUQAAgSAIgPQAHgOAOgIQANgJASAAQAUAAAOAJQAOAJAIATIgVAIQgEgMgJgGQgJgGgNAAQgRABgKAKQgKAMAAAUQAAAVAKAMQALALASABQAQgBAIgHQAIgHAAgMIAAgCIgcAAIAAgUIAzAAIAABDIgQAAIgDgNQgGAHgJAFQgKADgMAAQgRABgOgJg");
	this.shape.setTransform(41.475,276.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9FF98").s().p("AAaA/Ig0hWIAABWIgWAAIAAh9IAXAAIA0BWIAAhWIAWAAIAAB9g");
	this.shape_1.setTransform(28.175,276.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9FF98").s().p("AgKA/IAAh9IAVAAIAAB9g");
	this.shape_2.setTransform(18.725,276.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9FF98").s().p("AAaA/Ig0hWIAABWIgWAAIAAh9IAXAAIA0BWIAAhWIAWAAIAAB9g");
	this.shape_3.setTransform(9.275,276.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9FF98").s().p("AAaA/Ig0hWIAABWIgWAAIAAh9IAXAAIA0BWIAAhWIAWAAIAAB9g");
	this.shape_4.setTransform(-3.975,276.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9FF98").s().p("AAiA/IgJgaIgxAAIgJAaIgZAAIAzh9IAQAAIAyB9gAARAQIgRgtIgQAtIAhAAg");
	this.shape_5.setTransform(-16.675,276.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9FF98").s().p("AglA/IAAh9IAWAAIAABoIA1AAIAAAVg");
	this.shape_6.setTransform(-26.8,276.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9FF98").s().p("AgpA/IAAh9IApAAQAUAAALAJQALAKAAARQAAATgLAIQgLAKgUAAIgTAAIAAA0gAgTgJIARAAQALAAAFgEQAFgEAAgIQAAgJgFgDQgFgEgLAAIgRAAg");
	this.shape_7.setTransform(-37.025,276.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9FF98").s().p("AgLA/IAAhoIgmAAIAAgVIBjAAIAAAVIgmAAIAABog");
	this.shape_8.setTransform(24.75,259.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9FF98").s().p("AAVA/Igdg0IgIAAIgIAAIAAA0IgWAAIAAh9IApAAQAVABAKAJQAKAJAAARQAAAOgFAJQgHAHgKAEIAhA3gAgYgJIAQAAQALAAAFgEQAGgDAAgJQAAgJgGgEQgFgDgLAAIgQAAg");
	this.shape_9.setTransform(14.65,259.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9FF98").s().p("AAiA/IgJgaIgxAAIgJAaIgZAAIAzh9IAQAAIAyB9gAARAQIgRgtIgQAtIAhAAg");
	this.shape_10.setTransform(2.425,259.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9FF98").s().p("AgKA/IAAhoIgoAAIAAgVIBkAAIAAAVIgnAAIAABog");
	this.shape_11.setTransform(-8.7,259.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D9FF98").s().p("AgUA8QgKgEgHgJQgGgIgCgMIAWgFQACALAHAGQAGAGAKAAQAKAAAFgEQAGgFAAgIQAAgGgFgFQgGgFgNgFQgNgFgIgFQgIgFgDgHQgEgGAAgJQABgKAEgIQAFgIAJgEQAJgEAKAAQANAAAKAFQAKAGAGALIgTAMQgDgHgGgEQgFgDgGAAQgGAAgEAEQgFADAAAGQAAAGAFAFQAGAEANAGQANAFAIAFQAIAEADAHQAEAGAAAJQAAAMgGAJQgFAIgKAFQgKAFgNAAQgMAAgKgFg");
	this.shape_12.setTransform(-18.975,259.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},66).to({state:[]},1).wait(53));

	// button_bg
	this.instance = new lib.Shape13();
	this.instance.setTransform(-61.75,207.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(66).to({_off:true},1).wait(53));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95.2,-303.7,190.5,607.5);


(lib.Artboard1svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Artboard_1_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5001").s().p("Ai0MaQg/gKhshBQhuhCgWgtQgJgMgFgZQgIgyAZhDIFBtlIgQACQkEAfgLAEQgLAEgOgNQgUgSgRgiQgSgkAGgRQADgKAKgCQATgEBfgOQCKgTCTgOIABAAIBBisIAAgHQgHgOABgLQAAgIAGgJQAHgLAMgEQAMgEANADQASAEALAEQBMAYBAAmQBwBBANBLIAAACIDSgMIABAAIAFABQAEACADAEQAHAKgJAUQgTAtgPAMQgGAFgIABQgIACgSACIgTACIiLASIgHABIgBADIAAgBQhWDeknMvIgUA/QgUBJAEAzQABARgMAKQgJAJgOAAg");
	this.shape.setTransform(397.0015,138.7984);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5001").s().p("AABIUQhigQhIgXQhlgggTgpQgKgMgEgZQgIgyAZhDQAYhACjmNIB9k5QAHgMALgGQARgKAZAIIAHACQA/AVAoAVQBKAoAYA0IAAgBQAZA0gZA+QhACfiZGtIgVBAQgTBJAEAzQABAQgMAKQgKAJgNAAg");
	this.shape_1.setTransform(439.8485,165.0096);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF5001").s().p("AiNJTQg/gBg6gXQgmgPgegWQgIgGgKgJQhnhtARhyQAOhfBchaQA0gyA+glQgkhbgChbQgBhbAhhSQAehKA4g6QA3g6BHggQBxgzBoANQA3AGAhAUQBMAiAhAsQAhAtgCBAQgDA+gUALQgNAHgVgMQgKgFgHgNQgEgJgGgRIgDgKQgJgXgcgWIgcgTQhAgcg8ApQgTAOgQATQgIAJgGAJQg+BaBHD8QAjB9AxBvQA6CfhHBhQguBAhkAhQhSAchfAAgAjqDTIgVArQgWBKAPAvQAJAcASAMIABAAQAkgLAYglQAMgTAFgRIAAAAQAOgvgLg6QgHgkgOggQggAIgbAtg");
	this.shape_2.setTransform(309.8073,158.776);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF5001").s().p("AE4RDQhEgLh2hFQh5hHgWgvQgNgggBgSQgIg2Aag9IBWjuQh+AMiWASQkGFHhrB9Qg6BDgrAXQg4AdhgAAQh7AAgVgdQgHgLAEgPQAFgOAQgLQBUg9AkgdQAdgXAXgYQAGgHD3kwIhvARQioAbgtATIgBAAQgEACgGAAQgOAAgNgKQgKgKgXgdQgYgfgWgkQg8hfAAgwQAAgOAHgKQAGgKANgDQBAgUCygNQC5gNDkAAIAqAAQLlubE8mMQgGgOABgKQAAgHAGgJQAHgLALgEQAMgEAOADIAfAJQBiAgAfASQAmAWATArQAYAzgXA4IkOLaIABAAQh6FEjoKSQgYBKgJBAQgEAhgBAcQgEAWgIAHQgKAJgOAAgAgWEmQBIADBbAHICUmSg");
	this.shape_3.setTransform(102.7503,109.1234);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF5001").s().p("AiTC0IBakXIhgAAIAahQIEZAAIgaBQIhfAAIhZEXg");
	this.shape_4.setTransform(361.175,48.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF5001").s().p("AhmC0IBzlnIBbAAIh0Fng");
	this.shape_5.setTransform(324.95,48.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF5001").s().p("AhtChQgfgVgMgfIgDgIIBMgvIAGAKQASAoAlAAQASAAALgIQANgHACgMQAAgJgFgHQgGgHgVgQIgOgKQgigYgNgZQgNgaAGgiQAGgvAkgbQAigcA1AAQBBAAAfAvIAFAIIhIA2IgFgJQgIgLgHgFQgIgFgMAAQgQAAgJAJQgFAHgBAHQgBAJAFAGQAEAIARALIAQAKQAkAZANATQATAdgFAmQgHAzgnAeQgnAdg6AAQgwAAgjgXg");
	this.shape_6.setTransform(292.9,48.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF5001").s().p("AhmC0IBzlnIBbAAIh0Fng");
	this.shape_7.setTransform(264.05,48.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF5001").s().p("Ah1C1IgzlpIBaAAIASCIQACANABAjQAVgiAMgPIBhiHIBhAAIkKFpg");
	this.shape_8.setTransform(236.45,48.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF5001").s().p("AlbE2QhAgdgbhFQgYg/AkhBQAjhBBTgrQBAgiA7AHQA7AHAoAvIBYjZQAEgOALgKQAOgOARADQAqAFBTgMQBwgRBmgqQAOgHAOgCQAQgCAJAHQANALgHAYQgFASgVAtQgVAvgJAKIgCADQgIAJgIAFQgQAHgfAFQiJATh1gmQgJgDgJAAQgRAAgGAOQgQAtg4DYQgnCTh5AuQglAOgmAAQglAAghgPg");
	this.shape_9.setTransform(495.0675,78.7278);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF5001").s().p("AD6IpQhlgQhGgWQhkghgUgoQgJgMgEgaQgJgxAahEQAdhNB9lcIBIjHQg/BUhVCIQhjCghECIIhECRQgPAjgJAtQgKAyADAqQACAPgNANQgMALgQgDQhOgMhDgWQhqgigWgsQgJgMgEgaQgJgxAahEIA7igQCcmkAYg7IAshxQACgEgCgDQgHgOABgLQABgIAFgJQANgWAhAGIAeAIIADABQDvBPAABOQAAAFgUAxIghBRQAQgRAvhEQAuhBAIgHQAkgmA4gzQAFgHAWgHQAhgLAnAMIBeAnQBdAxAeA9IAAgBQAZAzgWA2QhBCeiZGuIgUA/QgTBJADAzQACAQgMALQgKAJgOAAg");
	this.shape_10.setTransform(524.9586,162.8522);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF5001").s().p("ADvIfQhkgQhHgXQhkgggUgpQgJgMgFgZQgIgyAZhDIAMggQikDagGAMIgBAAIgPAUQgQAWgLAJQgMALgogLQgagIgbgNQg5gaguggQg2gmgPgeQgKgMgEgZQgIgyAZhDIBSjhQBtktAYg9IAthyIAAgHQgHgOABgLQAAgHAGgJQAHgLAMgEQAMgFAOAEIAeAHIADABQC7A/AsBcQAYA0gXA5QguB1iNGFQBAhLBChkQBgiQBQiqIBij2QAHgMALgHQATgJAYAIIAHACQA/AVAoAVQBJAnAZA0QAZA1gaA9QhACfiZGtIgUBAQgTBJADAzQABAQgMAKQgJAJgOAAg");
	this.shape_11.setTransform(214.386,163.9484);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,580.3,218.3);


(lib.Logo_svg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Asset_1_svg
	this.instance = new lib.Artboard1svg("synched",0);
	this.instance.setTransform(-0.25,-0.1,0.1524,0.1523,0,0,0,290,109);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(56).to({startPosition:0},0).to({_off:true},1).wait(17).to({_off:false},0).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.4,-16.7,88.4,33.3);


// stage content:
(lib.VATX_banner_outdoors_1_springs_300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// grain_mask2
	this.instance = new lib.grain_mask2();
	this.instance.setTransform(150.5,300);
	this.instance.compositeOperation = "overlay";

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(120));

	// for_a_show
	this.instance_1 = new lib.for_a_show_textfade("synched",0);
	this.instance_1.setTransform(223.7,526.2,1.1161,1.116);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({_off:false},0).to({alpha:1},13).wait(73));

	// youre_in
	this.instance_2 = new lib.youre_in_textfade("synched",0);
	this.instance_2.setTransform(236.4,495.7,1.2232,1.2202,0,0,0,0.6,-0.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({_off:false},0).to({alpha:1},11).wait(86));

	// top_text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5001").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAFgGAJAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAFgJABQgJgBgFgFg");
	this.shape.setTransform(230.1,71.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5001").s().p("AgjBhQgEgEAAgJQAAgHACgKQACgKAFgNIAlh6IgWAAIABgFIA2gRIgvCZIgEAOIgBAKQAAAAAAABQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAAAAAAAAQABABAAAAQABAAAAAAQAFAAAHgJQAGgIAIgPIAFADQgMAWgMAMQgMANgLAAQgHAAgEgEg");
	this.shape_1.setTransform(224.9,63.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF5001").s().p("AgvA+QgMgMAAgYQAAgQAFgQQAGgQAKgPQAKgPAPgKQANgJARgBQAUAAAMAMQAKAMABAXQAAAPgGARQgFARgKAOQgLAQgOAJQgOAKgRAAQgUAAgKgLgAACg4QgHAHgGAMQgGAMgFAOQgGAMgCAOQgDANAAAKQAAAOAFAGQADAGAIAAQAIAAAIgHQAHgHAGgMQAGgMAFgOQAFgMADgOQACgNABgKQAAgOgFgGQgEgGgIAAQgHAAgIAHg");
	this.shape_2.setTransform(214.8,66.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF5001").s().p("AgwA+QgLgMAAgYQAAgQAGgQQAEgQALgPQAKgPAOgKQAOgJASgBQATAAALAMQAMAMAAAXQAAAPgFARQgGARgKAOQgKAQgPAJQgOAKgRAAQgTAAgMgLgAACg4QgHAHgGAMQgHAMgFAOQgEAMgDAOQgDANAAAKQAAAOAEAGQAFAGAHAAQAIAAAIgHQAHgHAGgMQAGgMAFgOQAFgMADgOQACgNAAgKQAAgOgEgGQgEgGgHAAQgJAAgHAHg");
	this.shape_3.setTransform(202.7,66.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF5001").s().p("AgsA+QgJgLAAgUQAAgRAHgQQAIgTAMgPQAMgQAOgKQAPgJARgBQAKAAAGAFQAGAGAAAKQAAAHgEAJQgDAHgIAHIgCAAIAAgKQAAgOgFgHQgDgIgLAAQgKABgHAHQgHAGgHAMQgFAMgFAOQgDAOAAAOQAAAPAFAKQAGAJALAAQALAAAKgJQALgJAJgRIAEACQgNAagPANQgNANgRAAQgRAAgKgLg");
	this.shape_4.setTransform(192.25,66.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF5001").s().p("AAIBFQgEgEAAgJIADgRIAHgXIACgHQgJARgJAOQgKAOgLAKQgKAJgKAAQgMgBgGgHQgGgIAAgOQABgNAEgOQAFgQAJgPQAIgPAMgNQALgNAOgIQAMgHAOgBQAJAAAHACQAHAEAGAEIALgKIAFAAIgfBhIgFAUQgBAHAFABQAFgBAGgHQAHgIAIgOIAEACQgMAXgNAMQgMANgLAAQgHAAgDgEgAgEgzQgKAKgIAPQgJAPgEAPQgFAQAAAOQAAAIACAFQACAFAHAAQAHgBAJgJQAIgKAJgPQAJgQAJgSQAIgRAGgSQgEgEgEgCQgFgCgGAAQgMAAgJAJg");
	this.shape_5.setTransform(176.275,66.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF5001").s().p("AgqBRQgGgFgBgMQAAgMAGgUIAXhGIgSAAIABgEIA1grIAEAAIgKAdIAoAAIgFASIgoAAIgYBNQgFAOACAIQABAIAJAAQAEAAAFgDQAEgDAHgIQAGgIAIgNIAEACQgPAbgMAMQgOALgLAAQgKAAgGgFg");
	this.shape_6.setTransform(167.3731,65.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF5001").s().p("AgqBRQgGgFgBgMQAAgMAGgUIAXhGIgSAAIABgEIA1grIAEAAIgKAdIAoAAIgFASIgoAAIgYBNQgFAOACAIQABAIAJAAQAEAAAFgDQAEgDAHgIQAGgIAIgNIAEACQgPAbgMAMQgOALgLAAQgKAAgGgFg");
	this.shape_7.setTransform(159.6731,65.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF5001").s().p("AgvA+QgMgMAAgYQAAgQAFgQQAFgQALgPQAKgPAOgKQAOgJASgBQATAAALAMQALAMABAXQAAAPgGARQgFARgKAOQgLAQgOAJQgOAKgRAAQgUAAgKgLgAACg4QgGAHgHAMQgGAMgGAOQgFAMgCAOQgDANAAAKQAAAOAFAGQADAGAIAAQAIAAAIgHQAGgHAHgMQAGgMAFgOQAFgMADgOQACgNABgKQAAgOgFgGQgEgGgHAAQgJAAgHAHg");
	this.shape_8.setTransform(148.55,66.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF5001").s().p("AgjBhQgEgEAAgJQAAgHADgKQACgKAEgNIAmh6IgXAAIABgFIA2gRIgvCZIgEAOIgCAKQAAAAABABQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAAAAAAAAQABABAAAAQABAAABAAQAEAAAGgJQAHgIAIgPIAEADQgLAWgMAMQgNANgKAAQgHAAgEgEg");
	this.shape_9.setTransform(140.35,63.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF5001").s().p("AgtA+QgJgLAAgUQAAgQAHgRQAIgTAMgPQAMgQAPgKQAPgJARgBQAMAAAGAHQAFAFAAAJQAAAPgUAOQgUAOgoALIgCAKIAAAJQAAAOAGAJQAFAIAMABQAKAAAKgJQAKgJAKgRIAEACQgNAagOANQgOANgRAAQgSAAgJgLgAACg0QgIAIgHAMQgGAOgEAPQAUgHALgIQANgJAEgIQAFgJAAgGQAAgFgCgDQgCgDgFAAQgKAAgJAJg");
	this.shape_10.setTransform(127.6,66.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF5001").s().p("AgjBhQgEgEAAgJQAAgHACgKQACgKAFgNIAlh6IgWAAIABgFIA2gRIgvCZIgEAOIgCAKQAAAAABABQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAAAAAAAAQABABAAAAQABAAABAAQAEAAAHgJQAGgIAJgPIAEADQgMAWgMAMQgMANgLAAQgHAAgEgEg");
	this.shape_11.setTransform(120.15,63.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF5001").s().p("AgvA+QgMgMAAgYQAAgQAFgQQAGgQAKgPQAKgPAPgKQANgJARgBQAUAAAMAMQAKAMABAXQAAAPgGARQgFARgKAOQgLAQgOAJQgOAKgRAAQgUAAgKgLgAACg4QgHAHgGAMQgGAMgFAOQgFAMgDAOQgDANAAAKQAAAOAEAGQAEAGAIAAQAIAAAIgHQAHgHAGgMQAHgMAEgOQAFgMADgOQACgNABgKQAAgOgEgGQgFgGgIAAQgHAAgIAHg");
	this.shape_12.setTransform(110.05,66.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF5001").s().p("AANBiQgEgEAAgIQAAgHAEgNIAKgeIAQgoQADgJgCgFQgCgFgFAAQgGABgKAKQgKAKgLAQQgLAQgKAUQgKAUgGAUIgDAIIgaAAIA3iwIgXAAIABgFIA2gRIgoCEQAHgNAJgOQAIgMALgLQAKgMALgHQAKgGAJgBQALABAEAFQAEAGgCALQgBAKgFANIgTAwQgFAPgCAJQgBAIAEAAQAFAAAHgIQAHgIAIgPIAEACQgIAQgIAKQgJALgJAGQgIAFgHAAQgGAAgDgDg");
	this.shape_13.setTransform(96.775,63.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF5001").s().p("AgNBKIAHhSIg+BVIgEgDIALh3IgBgIQgBgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQgDAAgGAHQgGAGgIAOIgEgCQANgWALgLQALgMAKAAQAKABACAIQACAJgBAPIgJBOIARgcIAUgfIAQgeIALgWIAFAAIgNB4QAWgbAMgRQAMgTAGgMQAFgNAAgGIgBgFQgBAAAAgBQgBAAAAAAQgBgBAAAAQgBAAgBAAQgDAAgEAEQgFAEgHALIgEgDQAMgSAKgIQAKgJAJAAQAIABACAEQADAEAAAFQAAAMgLARQgLASgXAaIg6BCg");
	this.shape_14.setTransform(82.2786,66.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF5001").s().p("AgsA8QgNgLAAgUQAAgKAEgJQAEgHAIgEQAHgFANgCQAMgBATAAIAdAAIAAgHQAAgSgJgKQgKgKgRABQgMgBgKAHQgLAFgIAMIgOgMQALgPAOgGQAOgIAQAAQAaAAAPAPQAOAOAAAaIAABVIgSAAIgBgVQgIAMgNAFQgMAHgPgBQgXAAgMgLgAgQAHQgJABgFAEQgEADgCAEQgCAFAAAGQAAAMAJAGQAKAHAPAAQATAAAMgNQALgNABgWIAAgCIgbAAQgSAAgKACg");
	this.shape_15.setTransform(59.125,66.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF5001").s().p("AgpBGIAAiJIATAAIAAAVQAIgOALgFQALgEAKAAQAHAAAFABQAHACAFADIgKAPIgJgDIgJgBQgPAAgKAMQgLAMAAAWIAABMg");
	this.shape_16.setTransform(43.95,66.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FF5001").s().p("AgiA+QgPgJgIgRQgIgQAAgUQAAgUAIgQQAIgQAPgJQAPgKATAAQAUAAAOAKQAPAJAJAQQAIAQAAAUQAAAUgIAQQgJARgOAJQgPAJgUAAQgTAAgPgJgAgZguQgKAHgGAMQgFAMAAAPQAAAQAGAMQAFAMALAHQAKAHAOAAQAPAAAKgHQALgHAFgNQAGgMAAgPQAAgPgGgMQgFgMgLgHQgKgHgPAAQgOAAgLAHg");
	this.shape_17.setTransform(31.225,66.65);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FF5001").s().p("AgOBjIAAh5IgdAAIAAgQIAdAAIAAgWQAAgOAFgIQAFgJAHgDQAIgEAJAAIAMACQAGABAGADIgGAPIgJgDIgHgBQgJAAgEAFQgFAFAAAKIAAAXIAoAAIAAAQIgoAAIAAB5g");
	this.shape_18.setTransform(20.425,63.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FF5001").s().p("AgtBDQgJgFAAgLQAAgDACgEIAGgGIAEAAQAHALAHAHQAHAHAKAAQAKAAAEgFQAGgFAAgKQAAgIgGgKQgDgIgIgJIgLgSQgGgJAAgKQABgNAGgKQAHgKALgEQAKgFAOgBQAOABAIAEQAIAFAAAIQAAADgBAEIgGAHIgDAAQgHgKgHgGQgGgHgJAAQgJABgFAFQgEAFAAAHQAAAKAEAIQAFAJAIAJIAMARQAFAKAAALQAAANgHAKQgHAKgLAGQgLAFgNAAQgRAAgKgGg");
	this.shape_19.setTransform(198.05,39.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FF5001").s().p("Ag/BWQgLgIAAgNQAAgJAIgKQAJgKARgKIgFgFQgCgDAAgFQAAgGAFgFQAFgGAJgGQgFgFgDgGQgDgGAAgIQAAgKAEgKQAFgLAHgIQAIgIAKgFQAKgFAMgBIAKABIAIACIAoAAIgDAJIgXAAQAEAEACAHQACAFAAAHQAAAKgFAJQgEAKgHAJQgIAJgKAFQgLAFgMAAQgHAAgGgCIgKgDIgEADIgBAEQAAADAHAFIAQAGIASAIQAJAFAHAGQAGAGAAAIQAAANgJAKQgKALgQAFQgOAHgSAAQgUgBgLgHgAgyAsQgEAHAAAGQAAALAKAGQAKAGARABQAJAAAIgDQAHgCAEgEQAFgEAAgFQAAgHgFgEQgGgEgHgEIgSgHQgJgDgHgFQgJAHgFAIgAAEhOQgFAFgFAJQgEAJgDAKQgDAJAAAJQABAIAEAFQAEAFAHAAQAGAAAHgGQAGgFAEgKQAFgIADgKQACgKAAgIQAAgJgEgEQgFgGgGAAQgHAAgHAHg");
	this.shape_20.setTransform(188.975,41.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FF5001").s().p("AAMBFQgDgDAAgIQAAgHADgNIALgeIAQgoQADgKgCgEQgCgFgFAAQgGAAgKALQgLAKgKARQgKAPgKAUQgKAUgHAUIgCAIIgbAAIAehWIAFgRQABgIAAgFQgBgFgDABQgFAAgHAIQgHAHgIAOIgDgCQAMgWANgNQANgNAKgBQAHABADADQAEAFAAAGQAAAJgEALIgHAaIgGAPQAHgNAKgNQAHgOALgLQAKgLAKgHQALgHAIAAQALABAEAFQAEAGgBALQgBAKgFANIgSAwQgGAPgBAIQgCAJAEAAQAFAAAHgJQAIgHAHgPIAEACQgIAQgIAKQgJAKgIAHQgJAFgHAAQgGAAgEgEg");
	this.shape_21.setTransform(176.95,39.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FF5001").s().p("AggBiQgEgDgBgIQAAgIAFgMIAJgdIALgcIAGgQQABgHAAgEQAAgFgFAAQgEAAgHAIQgHAIgIANIgEgCQAMgVANgOQANgNAKAAQAIAAAEAEQADAFAAAHQAAAIgCAKIgJAXIgNAkQgFAQgCAIQgBAJAFAAQAEAAAGgIQAHgIAIgPIAEACQgIAPgJALQgIAKgIAGQgJAGgGAAQgHAAgCgEgAAKhFQgGgFAAgIQAAgIAGgFQAEgGAIAAQAJAAAFAGQAFAFAAAIQAAAIgFAFQgFAFgJAAQgIAAgEgFg");
	this.shape_22.setTransform(167.4,36.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FF5001").s().p("Ag6BIIAdhXIAGgRQABgIAAgEQgBgFgDAAQgFAAgHAIQgHAHgIAPIgDgDQAMgVANgOQANgNAKAAQAHAAABADQADAFAAAHQAAAIgDAKIgIAcIgEAMQAJgVAJgQQAKgRAKgJQAKgKAIAAQAIAAADADQAEAEAAAFIgBAGIgEAFIgIAAQgVAAgUAeQgSAcgRA5IgBAEg");
	this.shape_23.setTransform(159.55,38.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FF5001").s().p("AhIBcIAniAIAEgRQACgHAAgFQAAgFgEAAQgEAAgHAIQgHAIgIAOIgEgDQAMgVANgOQANgNALAAQAHAAADAEQADAEAAAJQgBAIgCALIgHAZIgBAFQAJgSAJgOQAKgQALgJQALgJAKAAQAMAAAGAIQAFAHAAAOQAAANgFAPQgEAQgJAPQgJAOgLAOQgMANgNAHQgMAIgOAAIgJAAIgIgCIgNApgAAUg8QgIAJgKAQQgIAQgJASQgIARgGASQADADAFACQAFADAGAAQAKAAALgKQAKgKAIgOQAIgOAFgRQAFgQAAgOQAAgHgCgFQgDgFgGAAQgHAAgJAKg");
	this.shape_24.setTransform(146.925,41);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FF5001").s().p("AgsBDQgKgFABgLQAAgDABgEIAGgGIAEAAQAHALAHAHQAHAHAKAAQAKAAAEgFQAGgFAAgKQAAgIgGgKQgEgIgGgJIgMgSQgGgJAAgKQAAgNAHgKQAHgKALgEQAKgFAOgBQAOABAIAEQAIAFABAIQAAADgCAEIgGAHIgDAAQgHgKgHgGQgGgHgJAAQgJABgFAFQgEAFAAAHQAAAKAEAIQAGAJAGAJIANARQAFAKAAALQAAANgHAKQgHAKgLAGQgLAFgNAAQgRAAgJgGg");
	this.shape_25.setTransform(136.65,39.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FF5001").s().p("AgfA+QgPgKgGgPQgIgRABgTQgBgTAIgQQAGgRAOgJQANgKAUAAQAUAAAOAKQANAIAHAPQAFAPAAAQIAAAGIgBAFIhjAAQAAAXAMANQAMAMATAAQALABAKgEQAJgEAKgJIAOALQgMANgOAFQgNAGgPgBQgUAAgOgJgAgUgwQgJAGgFAKQgFAKgBAMIBSAAIAAgCIAAgCQgBgMgFgJQgFgJgJgFQgIgFgNAAQgMAAgJAGg");
	this.shape_26.setTransform(118.8,39.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FF5001").s().p("AAkBiIAAhQQAAgWgIgLQgHgKgQAAQgTAAgKAQQgKAOAAAdIAABAIgUAAIAAjDIAUAAIAABOQAGgLAMgGQAMgGAOAAQAXAAALAOQALAPAAAaIAABVg");
	this.shape_27.setTransform(105.6,36.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FF5001").s().p("AgFBXQgJgIAAgSIAAhZIgXAAIAAgQIAXAAIAAgkIASgPIAAAzIAhAAIAAAQIghAAIAABWQAAAKAEAFQAFAFAJgBIAHAAIAIgDIABARIgLADIgKABQgPABgHgJg");
	this.shape_28.setTransform(94.65,36.75);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FF5001").s().p("Ag+BjIAAjCIATAAIAAASQAIgKAMgFQALgGAOAAQATAAAOAJQANAJAIAQQAHAQAAAWQAAAUgHAPQgHAQgNAKQgOAJgUAAQgOAAgMgFQgLgGgIgKIAABMgAghhCQgMAPAAAZQAAAPAFAMQAFAMAKAHQAKAHAPAAQAOAAAKgHQAKgHAFgMQAFgMAAgPQAAgZgMgPQgMgPgUAAQgVAAgMAPg");
	this.shape_29.setTransform(76.725,41.875);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FF5001").s().p("AgrA3QgLgPAAgaIAAhTIATAAIAABPQAAALACAKQADAKAGAGQAGAGAOAAQAMAAAJgIQAKgHAFgNQAEgOAAgRIAAg/IATAAIAACJIgTAAIAAgUQgIALgMAGQgMAFgNAAQgXAAgLgPg");
	this.shape_30.setTransform(61.8,39.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FF5001").s().p("AgFBXQgJgIAAgSIAAhZIgXAAIAAgQIAXAAIAAgkIASgPIAAAzIAiAAIAAAQIgiAAIAABWQAAAKAEAFQAFAFAJgBIAHAAIAJgDIAAARIgLADIgKABQgOABgIgJg");
	this.shape_31.setTransform(43.55,36.75);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FF5001").s().p("AgJBiIAAiKIATAAIAACKgAgKhEIAAgdIAVAAIAAAdg");
	this.shape_32.setTransform(37.5,36.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FF5001").s().p("AAyBiIAAhaIhkAAIAABaIgTAAIAAjDIATAAIAABXIBkAAIAAhXIAUAAIAADDg");
	this.shape_33.setTransform(25.75,36.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(120));

	// button_withtext
	this.instance_3 = new lib.button_withtext("synched",0);
	this.instance_3.setTransform(61.75,394);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(53).to({_off:false},0).to({y:296.25,startPosition:24},24,cjs.Ease.cubicOut).wait(43));

	// Logo_svg
	this.instance_4 = new lib.Logo_svg("synched",0);
	this.instance_4.setTransform(229.65,463.6,1.2097,1.209);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(5).to({_off:false},0).to({regX:0.1,regY:0.1,scaleY:1.206,x:229.75,y:463.7,alpha:1,startPosition:74},12).wait(103));

	// Image
	this.instance_5 = new lib.Image();
	this.instance_5.setTransform(0,30);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(120));

	// background
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#E3DBD2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_34.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(120));

	// stageBackground
	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgY/gwbMAx/AAAMAAABg3Mgx/AAAg");
	this.shape_35.setTransform(150,300);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("EgY/AwcMAAAhg3MAx/AAAMAAABg3g");
	this.shape_36.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36},{t:this.shape_35}]}).wait(120));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(150,300,151,397.79999999999995);
// library properties:
lib.properties = {
	id: '983937C204075141B3A5B8AE1ED7E9D6',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/GrainLightpngcopy.png", id:"GrainLightpngcopy"},
		{src:"images/Image.png", id:"Image"},
		{src:"images/Shape13.png", id:"Shape13"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['983937C204075141B3A5B8AE1ED7E9D6'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;